class CONSTANT():

    CHROME_DRIVER = "/home/sanjeev/TestScripts/chromedriver"
    RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Resumes/"
    PROFILE_PIC_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Images/Image3.jpg"
    INPUT_DATA_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Input_Data/"


# DB Connection
    HOST = '10.0.3.35',
    DATABASE = 'coredbtest',
    USER = 'root',
    PASSWORD = 'root'

# Constants for Internal AMS

    INTERNAL_AMS_URL = "https://internalams.hirepro.in/ams"
    INTERNAL_AMS_LOGIN_NAME = "0003"
    INTERNAL_AMS_LOGIN_PASSWORD = "Ujjwal@123"
    INTERNAL_AMS_TENANT_ALIAS = "Test"

# Constant for AMS

    RPO_AMS_URL = "http://amsin.hirepro.in"
    #RPO_CRPO_AMS_URL = "https://internalams.hirepro.in/crpo/#/test/candidates/create"
    RPO_CRPO_AMS_URL = "https://ams.hirepro.in/crpo/#/bajaj/candidates/create"
    #CRPO_RPO_LOGIN_NAME = "5881"
    CRPO_RPO_LOGIN_NAME = "admin"
    CRPO_RPO_LOGIN_PASSWORD = "admin@123"
    RPO_AMS_PROJECT_NAME = "ams"
    RPO_AMS_ALIAS = "at"

# Constant for CRPO-RPO

   # CRPO_RPO_URL = getAppUrl(serverName)"http://amsin.hirepro.in/crpo"
    CRPO_RPO_TENANT_ALIAS = "RPOTESTONE"
    #CRPO_RPO_LOGIN_NAME = "admin"
    #CRPO_RPO_LOGIN_PASSWORD = "admin@123"
    RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Resumes/"

# Input data file names

    FILE_NAME_INTERNAL_AMS_COMMON = "InetrnalAMSCommon"