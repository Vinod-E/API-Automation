class CONSTANT():

    CHROME_DRIVER = "/home/sanjeev/TestScripts/chromedriver"
    RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Resumes3/"
    #RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/ResumeDocx/"
    #RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/DineshResume/Resumes/"
    PROFILE_PIC_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Images/Image3.jpg"
    INPUT_DATA_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Input_Data/"


# DB Connection
    HOST = '10.0.3.35',
    DATABASE = 'coredbtest',
    USER = 'root',
    PASSWORD = 'root'

# Constants for Internal AMS

    INTERNAL_AMS_URL = "http://10.0.3.41/crpo/#/test/candidates/create"
    INTERNAL_AMS_LOGIN_NAME = "0003"
    INTERNAL_AMS_LOGIN_PASSWORD = "Ujjwal@123"
    INTERNAL_AMS_TENANT_ALIAS = "Test"

# Constant for AMS

    RPO_AMS_URL = "http://amsin.hirepro.in"
    #RPO_CRPO_AMS_URL = "https://amsin.hirepro.in/crpo/#/rpotestone/candidates/"
    #RPO_CRPO_AMS_URL = "https://amsin.hirepro.in/crpo/#/rpotestone/candidates/create"
    RPO_CRPO_AMS_URL = "https://amsin.hirepro.in/crpo/#/rpotestone/candidates/"
    #CRPO_RPO_LOGIN_NAME = "5881"
    CRPO_RPO_LOGIN_NAME = "admin"
    CRPO_RPO_LOGIN_PASSWORD = "admin@123"
    RPO_AMS_PROJECT_NAME = "ams"
    RPO_AMS_ALIAS = "at"

# Constant for CRPO-RPO

   # CRPO_RPO_URL = getAppUrl(serverName)"http://amsin.hirepro.in/crpo"
    #CRPO_RPO_TENANT_ALIAS = "RPOTESTONE"
    #CRPO_RPO_LOGIN_NAME = "admin"
    #CRPO_RPO_LOGIN_PASSWORD = "admin@123"
    #RESUME_FILE_PATH = "/home/sanjeev/TestScripts/TestScripts/Resumes/"
    #RESUME_FILE_PATH_MUTHU = "/home/sanjeev/TestScripts/TestScripts/Resumes2/"

# Input data file names

    #FILE_NAME_INTERNAL_AMS_COMMON = "InetrnalAMSCommon"